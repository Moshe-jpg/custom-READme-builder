
  # Moshe's README generator


  ## <img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="Github license">


  ## It generates a README based on what the user inputs into the console



  ### Table of Contents
  
  * [Installation](#installation)

  * [Usage](#usage)

  * [License](#license)

  * [Contributing](#contributing)

  * [Tests](#tests)

  * [Questions](#questions)



  ## Installation
  #### Clone the repo on github and install node inquirer, then run index,js in the console



  ## Usage
  #### Answer the questions in the console



  ## License
This Project Is Licensed Under The MIT License



  ## Contributing
  #### Moshe, John, & Ryan



  ## Tests
  #### I ran it over and over and over



  ## Questions
  #### You can reach me at [moshe-great@gmail.com](moshe-great@gmail.com) if you have additional questions


  ## Created By:
  [moshe-jpg](github.com/moshe-jpg)
